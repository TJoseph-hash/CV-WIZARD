import express from "express";
import multer from "multer";
import pdfParse from "pdf-parse";
import { OpenAI } from "openai";
import dotenv from "dotenv";
import cors from "cors";
import {initializeApp} from 'firebase/app';
import {getAuth, onAuthStateChanged} from 'firebase/auth';
import { getAnalytics } from "firebase/analytics";

dotenv.config();

const app = express();
const upload = multer();
app.use(cors());

    const token= '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';
    const URL=  'https://models.inference.ai.azure.com'

const openai = new OpenAI({ baseURL: URL , apiKey: token});

app.post("/api/tailor-resume", upload.single("resume"), async (req, res) => {
try {
if (!req.file || !req.body.jobDescription) {
return res.status(400).send("Resume file and job description are required.");
}

// Extract text from PDF
const pdfText = await pdfParse(req.file.buffer).then(data => data.text);
const jobDescription = req.body.jobDescription;

// Call OpenAI API to tailor resume
const response = await openai.chat.completions.create({

messages: [
{ role: "system", content: "You are an expert resume tailor. Modify the resume to match the job description while keeping it professional and truthful." },
{ role: "user", content: `Resume:\n${pdfText}\n\nJob Description:\n${jobDescription}\n\nPlease tailor the resume accordingly.` }
],
 model: "gpt-4o",
 temperature: 1,
 max_tokens: 4096,
 top_p: 1
});

res.send(response.choices[0].message.content);
} catch (error) {
console.error(error);
res.status(500).send("Error processing request.");
}
});

app.listen(3000, () => console.log("Server running on port 3000"));


//Firebase authentication
/*
const firebaseConfig = {
    apiKey: "AIzaSyCk0h2I2bOCaOmzHt-xXWqFbCasJN_rwa4",
    authDomain: "cv-wizard-a212e.firebaseapp.com",
    projectId: "cv-wizard-a212e",
    storageBucket: "cv-wizard-a212e.firebasestorage.app",
    messagingSenderId: "613359155975",
    appId: "1:613359155975:web:b1077e2f1486f7476263a2",
    measurementId: "G-6CYE8MMP2P"
};

// Initialize Firebase

const firebaseApp = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth(firebaseApp);
const analytics = firebase.analytics(firebaseApp);

const signupForm = document.getElementById("signup-form");

signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const fullName = document.getElementById("name").value;
    const email = document.getElementById("gmail").value;
    const password = document.getElementById("Password").value;

    try {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        console.log("User signed up: ", user);
    } catch (error) {
        const errorCode = error.code;
        const errorMessage = error.message;
        console.error("Sign-up error: ", errorCode, errorMessage);
    }
});
*/