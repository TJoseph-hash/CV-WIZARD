import {initializeApp} from 'firebase/app';
import {getAuth, onAuthStateChanged} from 'firebase/auth';
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCk0h2I2bOCaOmzHt-xXWqFbCasJN_rwa4",
  authDomain: "cv-wizard-a212e.firebaseapp.com",
  projectId: "cv-wizard-a212e",
  storageBucket: "cv-wizard-a212e.firebasestorage.app",
  messagingSenderId: "613359155975",
  appId: "1:613359155975:web:b1077e2f1486f7476263a2",
  measurementId: "G-6CYE8MMP2P"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth= getAuth(app);
const analytics = getAnalytics(app);
